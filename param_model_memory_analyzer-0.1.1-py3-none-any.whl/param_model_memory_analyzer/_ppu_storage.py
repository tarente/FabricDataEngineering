from sempy_labs import admin
import pandas as pd

import param_model_memory_analyzer as pmma


def get_ppu_storage():
    # Get the PPU (PP3) Capacity
    capacity_id = (
        admin.list_capacities()
            .loc[lambda df: df["Sku"].eq("PP3"), "Capacity Id"]
            .iloc[0]
    )

    # Get the list of Workspaces assigned to PPU
    pd_workspaces = (
        admin.list_workspaces()
            .loc[lambda df: df["Capacity Id"].eq(capacity_id)]
            .rename(columns={"Id": "Workspace Id", "Name": "Workspace Name"})
            .loc[:, ["Workspace Id", "Workspace Name"]]
    )

    # Get the list of Semantic Models (Datasets) in the PPU Workspaces
    pd_list_datasets = (
        admin.list_datasets()
            .merge(pd_workspaces, on="Workspace Id", how="left")
            .loc[lambda df: ~df["Content Provider Type"].isin(["Unknown"])]
            .sort_values(["Workspace Name", "Dataset Name"])
    )

    # Iterate over all Semantic Models (Datasets) in the PPU Workspaces and calculate their size
    list_dataset_info = []

    for r in pd_list_datasets.to_dict("records"):
        workspace_name = r["Workspace Name"]
        workspace_id   = r["Workspace Id"]
        dataset_name   = r["Dataset Name"]
        dataset_id     = r["Dataset Id"]

        try:
            # --- HARD SANDBOX: catch ANY exception, including XMLA session failures ---
            try:
                pd_analysis = pmma.param_model_memory_analyzer(
                    dataset           = dataset_id,
                    workspace         = workspace_id,
                    return_dataframe  = True,
                    calc_table        = False,
                    calc_column_size  = False,
                    calc_partition    = False,
                    calc_hierarchy    = False,
                    calc_relationship = False,
                    calc_model        = True
                )
            except Exception as inner_exc:
                raise RuntimeError(f"Analyzer failed: {inner_exc}")

            # Extract Total Size
            total_size = pd_analysis["Model Summary"]["Total Size"].iloc[0] or 0

            list_dataset_info.append(
                {
                    "workspace_name": workspace_name,
                    "workspace_id":   workspace_id,
                    "dataset_name":   dataset_name,
                    "dataset_id":     dataset_id,
                    "total_size":     int(total_size)
                }
            )

        except Exception as exc:
            print(
                f"❌ Error analyzing 'Workspace Name' = '{workspace_name}' ('{workspace_id}'), "
                f"'Dataset Name' = '{dataset_name}' ('{dataset_id}'): '{exc}'"
            )

            list_dataset_info.append(
                {
                    "workspace_name": workspace_name,
                    "workspace_id":   workspace_id,
                    "dataset_name":   dataset_name,
                    "dataset_id":     dataset_id,
                    "total_size":     0
                }
            )

    # Convert the list of dataset info to a DataFrame
    pd_dataset_info = pd.DataFrame(list_dataset_info)

    return pd_dataset_info
